from brain import *
import json
print (learn)
x=input(':: ')
for pi in trains:
    if x==pi:trains.append('hia')
    
    newtrains=trains
    of=open('brain.py','a')
    of.write('trains='+json.dumps(newtrains)+'\n')
    of.close()
    from brain import *
if x=='hia':print(trains[2])
